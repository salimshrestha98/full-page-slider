import './editor.scss';

import {
	ColorPicker,
	Flex,
	FlexBlock,
	FlexItem,
	PanelBody,
	SelectControl,
	ToggleControl,
	__experimentalUnitControl as UnitControl
} from '@wordpress/components';
import { InspectorControls, RichText } from '@wordpress/block-editor';

import { __ } from '@wordpress/i18n';
import { useBlockProps } from '@wordpress/block-editor';
import { useSelect } from '@wordpress/data';

export default function Edit ( { attributes, setAttributes } ) {
	const {
		selectedAuthorId,
		author,
		showMore,
		moreText,
		backgroundColor,
		textAlign,
		padding
	} = attributes;


	const authors = useSelect( ( select ) => select( 'core' ).getEntityRecords( 'postType', 'author_profile', { per_page: 10 } ), [] );

	const selectedAuthor = authors?.find( ( author ) => author.id === selectedAuthorId );

	/**
	 * Set values for currently selected author.
	 * @param {int} value 
	 */
	function selectAuthor ( value ) {
		setAttributes( {
			selectedAuthorId: parseInt( value ),
			author: authors?.find( ( author ) => author.id == value )
		} );
	}


	return (
		<div { ...useBlockProps() }>
			<InspectorControls>
				<PanelBody title="Settings">
					<SelectControl
						label="Select Author"
						value={ selectedAuthorId }
						options={ [
							{ label: 'Select', value: 0 },
							...( authors?.map( ( author ) => ( {
								label: author.name,
								value: author.id
							} ) ) || [] )
						] }
						onChange={ ( value ) => selectAuthor( value ) }
					/>
					<ToggleControl
						label="Show More Section"
						checked={ showMore }
						onChange={ ( value ) => setAttributes( { showMore: value } ) }
					/>
					<ColorPicker
						label="Background Color"
						color={ backgroundColor }
						onChangeComplete={ ( value ) => setAttributes( { backgroundColor: value.hex } ) }
					/>
					<SelectControl
						label="Text Alignment"
						value={ textAlign }
						options={ [
							{ label: 'Left', value: 'left' },
							{ label: 'Center', value: 'center' },
							{ label: 'Right', value: 'right' }
						] }
						onChange={ ( value ) => setAttributes( { textAlign: value } ) }
					/>
					<UnitControl
						label="Padding"
						value={ padding }
						onChange={ ( value ) => setAttributes( { padding: value } ) }
					/>
				</PanelBody>
			</InspectorControls>

			<div style={ {
				backgroundColor,
				textAlign,
				padding
			} }>
				{ selectedAuthor ? (
					<Flex align='start'>
						<FlexItem>
							<img
								src={ selectedAuthor.thumbnail != '' ? selectedAuthor.thumbnail : 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png' }
								alt={ __( 'Profile Picture', 'super-blocks' ) }
								width="120px"
								height="120px"
								style={ { 'padding': '20px' } }
							/>
						</FlexItem>
						<FlexBlock>
							<>
								<h3>{ selectedAuthor.name }</h3>
								<p>{ selectedAuthor.email }</p>
								<p>{ selectedAuthor.description }</p>
							</>


							{ showMore && (
								<RichText
									tagName="p"
									value={ moreText }
									onChange={ ( value ) => setAttributes( { moreText: value } ) }
									placeholder={ __( "Add more info about the author here.", 'super-blocks' ) }
								/>
							) }
						</FlexBlock>
					</Flex>
				) : (
					<p>{ __( 'Select an author', 'super-blocks' ) }</p>
				) }
			</div>
		</div>
	);
}
