<p <?php echo get_block_wrapper_attributes(); ?>>
	<?php esc_html_e( 'Author Profile Block content displayed in frontend.', 'super-blocks' ); ?>
</p>
