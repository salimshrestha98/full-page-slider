import './style.scss';

import { __ } from '@wordpress/i18n';

export default function Save ( { attributes } ) {
	const {
		author,
		showMore,
		moreText,
		backgroundColor,
		textAlign,
		padding
	} = attributes;

	return (
		<div style={ {
			backgroundColor,
			textAlign,
			padding
		} }>
			{ ( typeof author == 'object' && author != 'undefined' ) ? (
				<div style={ { display: 'flex', alignItems: 'start' } } align='start'>
					<div>
						<img
							src={ author.thumbnail != '' ? author.thumbnail : 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png' }
							alt="Profile Picture"
							width="120px"
							height="120px"
							style={ { 'padding': '20px' } }
						/>
					</div>
					<div>
						<>
							<h3>{ author.name }</h3>
							<p>{ author.email }</p>
							<p>{ author.description }</p>
						</>

						{ showMore && (
							<p dangerouslySetInnerHTML={ { __html: moreText } }></p>
						) }
					</div>
				</div>
			) : (
				<p>{ __( 'No author selected.', 'super- blocks' ) }</p>
			) }
		</div>
	);
}
